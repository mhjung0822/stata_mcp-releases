---
name: stata-pull
description: |
  슬래시 명령어 /stata-pull 전용. 사용자가 /stata-pull 슬래시 명령어를 입력할 때만 트리거됨.
  Stata GUI에서 push된 결과를 StataMCP:getPushResults를 통해 즉시 가져오며,
  결과를 파싱하여 내용을 정리하여 출력하며, 외부 지식 및 추론은 추가하지 않음.
  자연어 Stata push 결과 요청에는 트리거하지 말 것 — 명시적인 /stata-pull 호출에만 반응.
---

# stata-pull

`/stata-pull` 호출 시:

1. `StataMCP:getPushResults` 실행
2. 결과 분기:
   - 결과 없음("No results pushed from Stata GUI yet.") → 그대로 출력
   - `output` 필드 있음 → 코드 블록으로 출력
   - `output` 필드 없음 → JSON 파싱하여 정리 출력
