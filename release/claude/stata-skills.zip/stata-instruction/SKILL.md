---
name: stata-instruction
description: |
  슬래시 명령어 /stata-instruction 전용. 사용자가 /stata-instruction 슬래시 명령어를 입력할 때만 트리거됨.
  StataMCP:getInstructions를 통해 현재 로드된 분석 지침 (stata_mcp_instructions.md) 내용을 즉시 조회하며,
  어떠한 해석, 수정, 모델 추론도 수행하지 않음.
  자연어 Stata 지침 요청에는 트리거하지 말 것 — 명시적인 /stata-instruction 호출에만 반응.
---

# stata-instruction

`/stata-instruction` 호출 시:

1. `StataMCP:getInstructions` 실행
2. 결과를 코드 블록으로 감싸서 그대로 반환
3. 에러 발생 시 에러 메시지를 코드 블록으로 감싸서 그대로 반환

인자를 받지 않으며, 결과를 수정·정제·평가하지 말 것. 코드 블록 앞뒤에 어떠한 설명도 추가하지 말 것.
