---
name: stata-setup
description: |
  슬래시 명령어 /stata-setup 전용. 사용자가 /stata-setup 슬래시 명령어를 입력할 때만 트리거됨.
  Stata 연결 상태를 확인하기 위해 정해진 순서대로 즉시 실행하며,
  어떠한 해석, 수정, 모델 추론도 수행하지 않음.
  자연어 Stata 연결 요청에는 트리거하지 말 것 — 명시적인 /stata-setup 호출에만 반응.
---

# stata-setup

`/stata-setup` 호출 시 아래 순서대로 즉시 실행:

1. `StataMCP:getStataPwd` 실행
2. `StataMCP:getObsCount` 실행
3. `StataMCP:getVariables` 실행

각 결과를 코드 블록으로 감싸서 그대로 반환. 추론, 해석, 설명을 추가하지 말 것.