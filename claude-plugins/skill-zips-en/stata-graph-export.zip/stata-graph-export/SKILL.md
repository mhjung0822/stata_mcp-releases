---
name: stata-graph-export
description: "Export a graph from Stata memory to a PNG file"
---

# stata-graph-export

## Guidelines
- View (vision) and analyze the image only if the user asks for it
- When graph analysis is needed, confirm with AskUserQuestion:
	1. question: "Shall Claude view and analyze the graph? (uses vision tokens)"
	2. options: ["Yes", "No"]

## Execution
- When `stata-graph-export [name]` is called, run this tool immediately:
	1. Run `stata_mcp_java: exportGraph` — with no argument pass `name=""` (current graph); with an argument pass that name
- If the `exportGraph` tool is not in the session's tool list (older server), say "The MCP server predates exportGraph — server update required" and stop

## Output
- On success, print only the `graphPath` file path from the response, as a file card
- On error (an `error` field), print the error JSON verbatim in a code block
- Perform no interpretation, no modification, and no model inference
