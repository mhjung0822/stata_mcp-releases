---
name: stata-instruction
description: |
  Triggered when the user types /stata-instruction, or when /stata-setup invokes it to load the instructions.
  Loads this session's Stata working instructions (output formats, analysis rules, preferences, etc.).
  Do not trigger on natural-language Stata requests — respond only in those two cases.
---

# stata-instruction — Stata MCP working instructions

Once this skill is loaded, treat the following as this session's **working instructions** and follow them in all subsequent Stata work and result presentation.

> **This skill is meant to be edited by you.** It is installed **separately** from the stata-mcp plugin, so updating the plugin never overwrites your edits. What follows is a **default example** — freely add or change not just output formats but analysis rules, favorite options, depth of interpretation, language, and any other session preferences (edit it directly in its options, or ask Claude to modify it).

## Execution format
- Before running a Stata command, first show the command to be run in a stata code block. Example:

  ```stata
  summarize price
  ```

- Show the full execution output in a code block as well (no arbitrary truncation)
- Exception: row-level data output like list/browse belongs in the Stata GUI (do not include it in responses)

## Interpreting results
- Expose the full raw output, and **in addition** append interpretation and a summary
  (pitched at an early-intermediate statistics level: unpack technical terms, give context on significance, effect sizes, and caveats)

## Graph output
- `graphDrawn: true` in an executeStata response means a graph was drawn (no PNG is created automatically)
- When an image is needed, call `exportGraph(name)` (empty name = current graph) → show `graphPath` as
  `[<graphFilename>](computer://<graphPath>)`. Do not embed the image inline
- If graph analysis is needed, AskUserQuestion ("use vision tokens?") → on "Yes" call `getGraphImage(path, maxDim:800)`.
  If `getGraphImage` is disabled, say so and hold off

## Presenting estimation results
- With multiple models, give each model its own table (never mix several dependent variables in one)
- Report coefficient + standard error + significance stars (*, **, ***)

## Categorical variables
- Prefix categorical regressors with `i.` in estimation commands (reg, xtreg, logit, …)
  when the variable has value labels or the user has defined it as categorical. Take care not to apply it to continuous variables
