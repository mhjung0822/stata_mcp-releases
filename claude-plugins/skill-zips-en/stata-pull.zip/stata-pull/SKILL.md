---
name: stata-pull
description: |
  Dedicated to the /stata-pull slash command. Triggered only when the user types the /stata-pull slash command.
  Immediately fetches results pushed from the Stata GUI, or completed async results, via StataMCP:getPushResults,
  parses them and presents the content tidily, adding no outside knowledge or inference.
  Do not trigger on natural-language Stata push-result requests — respond only to an explicit /stata-pull call.
---

# stata-pull

When `/stata-pull [mode]` is called:

1. Run `StataMCP:getPushResults` — with no argument, use `mode=""` (pull the oldest unread);
   if the user gave an argument, pass it through as the mode verbatim
2. Branch on the result:
   - `empty: true` + `asyncRunning: true` → print "async job running: <cmd> (<runningForSeconds>s elapsed)"
   - `empty: true` + `asyncRunning: false` → print "no new push results"
   - an entry received → first line summarizes `id / rc / note / durationMs`, then print `output` verbatim in a code block
3. On error, return the error message as-is, wrapped in a code block

Mode reference (pass through verbatim): `<id>` re-fetch / `consume` (pull+delete) / `history [keyword]` (index & search) /
`delete <id>` / `note <id> <text>` / `save [id]` / `load <path>`.
Pulling does not delete from the store — it only marks items as read; any result can be re-fetched anytime by `<id>`.
