---
name: stata-async
description: |
  Dedicated to the /stata-async slash command. Triggered only when the user types the /stata-async slash command.
  Immediately fires /stata-async $ARGUMENTS asynchronously (fire-and-forget) via StataMCP:executeStataAsync,
  performing no interpretation, no modification, and no model inference. Does not wait for completion.
  Do not trigger on natural-language Stata requests — respond only to an explicit /stata-async call.
---

# stata-async

When `/stata-async $ARGUMENTS` is called:

1. Pass `$ARGUMENTS` verbatim to `StataMCP:executeStataAsync`
2. Return the response (`started` or `busy`) as-is, wrapped in a code block
3. If `started`, append exactly one closing line: "Collect the finished results with `/stata-pull`"
4. Do not wait for completion and do not poll — fire it and end the turn immediately

Do not modify, clean up, or evaluate `$ARGUMENTS`. The output goes to the Stata Results window and the push store.
