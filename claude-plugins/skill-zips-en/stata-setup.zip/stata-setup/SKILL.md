---
name: stata-setup
description: |
  Dedicated to the /stata-setup slash command. Triggered only when the user types the /stata-setup slash command.
  Immediately executes a fixed sequence to check the Stata session environment (env, pwd, mounts)
  and load the session instructions.
  Do not trigger on natural-language Stata requests — respond only to an explicit /stata-setup call.
---

# stata-setup

When `/stata-setup` is called, run immediately in this order:

1. Run `StataMCP:getStataEnv`
2. Run `StataMCP:getStataPwd`
3. If the system prompt lists a mounted folder and it differs from the Stata pwd, confirm with AskUserQuestion:
   - question: "Change the Stata working directory to the cowork folder?"
   - options: ["Yes", "No"]
   - On "Yes": run `executeStata("cd \"<mount path>\"")` → report just the result (no follow-up questions)
   - On "No" → keep the current pwd
4. If the `stata-instruction` skill is installed, invoke it with the Skill tool to load the session working
   instructions (it is installed separately and user-edited — if absent, skip this step and proceed with default formatting)
5. Variable page — AskUserQuestion:
   - question: "Open the variable page?"
   - options: ["Yes", "No"]
   - "Yes": if this client has an in-app browser panel (Claude Code browser pane, Cowork browser panel), call
     `openVarsPage(launch=false)` and open the returned URL **in that panel**. Without a panel (plain chat), call
     `openVarsPage(launch=true)` to open it in the default browser
   - "No": just state the URL in one line (add that `/stata-vars` opens it later)
   - This is not Stata's own Variables pane (`window manage forward variables`) — never run that command for this

Do not echo the raw results of steps 1–2; show a **one-line summary** only — e.g. `Stata 19.5 MP (8 cores) · macOS · working folder /Users/…`.
Never print `adopath`, sysdir lists, theoretical limits (max_N_theory etc.) or byteorder (the tool response stays in context; consult it later if needed). Steps 3 (mount check), 4 (instruction load) and 5 (variable page) perform the defined actions.

## Tool guidance summary (v0.12.30) — keep in mind for the whole session

- **Variable page** (`http://127.0.0.1:<bridgeport>/vars`, `openVarsPage`): a server page where the user picks variables with
  checkboxes and Y/X tags. When the user says "the selected/checked/tagged variables", "the variables I picked in the page",
  or asks for an analysis without naming variables, **call `getSelectedVariables` first**.
  Rules — never guess: (1) "the selected variables" = `variables` (checked). If empty but tags exist, use Y ∪ X.
  (2) Requests needing no roles (summarize, tabulate, correlate, describe, graphs, data management such as order/drop):
  use that list as the varlist. (3) Model requests (regress, logit, xtreg, ...): `roles.y` = outcome, `roles.x` = regressors;
  if Y is empty or does not match what the model accepts, **ask** which variable is the outcome. (4) If both are empty, tell
  the user to pick variables in the page (or name them) and stop. (5) If `missing` is non-empty, say so in one line and
  continue with what remains. The page refreshes itself after commands run through MCP; commands typed directly in the
  Stata window appear after the page's refresh button.

- **Prefer StataMCP for natural-language Stata queries**: do not answer from your own knowledge first.
  Syntax/options/grammar → `getHelp`; actual computation, estimation, summaries, variable creation →
  `executeStata`, and ground your answer in the returned values (never produce numbers by computing them
  yourself). Long jobs (~30s+) → `executeStataAsync`. Data-mutating or destructive commands
  (drop/replace/clear/overwriting save etc.): confirm with the user before running. If the request is
  "syntax/explanation only", don't execute — just look it up with `getHelp`.
- **Never guess unverified facts**: verify via tool calls (reuse values already fetched); on failure, state "could not verify".
- **pwd changes mid-session**: a `pwdChange` field in an executeStata response means the user moved the
  working folder. If `pwdChange.to` differs from the mounted folder, ask whether to switch back to the mount.
- **Data-context refresh**: after changes to the data's structure or contents (use/merge/drop/generate/
  replace/reshape etc.), or whenever variable/observation info is needed but missing or stale, call
  `/stata-data-context` to refresh.
- **Long-running commands** (bootstrap/simulate/mi impute etc., ~30s+ expected): fire with
  `executeStataAsync` and keep the conversation going. Other Stata tools during the run return `busy`
  immediately. Completed results are delivered to the push store — collect with `getPushResults("")`,
  and use `asyncRunning`/`runningForSeconds` on an empty response to judge progress and set your polling interval.
- **Push store**: pulling is **marking as read**, not deletion — results are preserved.
  `history [keyword]` = chronological index & search (substring match over cmd+output+note);
  `note <id> <text>` = plain-language memo (searchable — tag async results after pulling them and they're
  easy to find later); `<id>` = full re-fetch; `consume`/`delete <id>` = deletion; `save [id]`/`load <path>` =
  JSON snapshots for continuing across sessions.
- **Single-value lookups go through `getMacro(name, type)` alone**: a bare name (`'b'`) probes
  local/global/scalar/matrix and returns everything found; stored results use full notation
  (`'e(r2)'`, `'e(cmd)'`, `'e(V)'`). getScalar/getMatrix were removed in v0.11.0.
- **Uncertain syntax, or response `rc` ≠ 0**: check with `getHelp` and self-correct. Abbreviations (`'su'`)
  resolve automatically; multi-word input (`'random effects'`) becomes a keyword search. Answers instantly
  even while an async job is running.
- **User interaction**: when the next step could go several ways, offer choices with AskUserQuestion
  rather than a plain question.
- `rc` in `executeStata` responses: 0 = success, anything else = a Stata error code (output is the raw log including the echo).
