---
name: stata-vars
description: |
  Dedicated to the /stata-vars slash command. Triggered only when the user types the /stata-vars slash command.
  Immediately opens the Stata MCP variable page (a server page) via StataMCP:openVarsPage, with no interpretation,
  modification or model inference. Do not trigger on natural-language Stata requests — respond only to an explicit /stata-vars call.
---

# stata-vars

When `/stata-vars` is called, run immediately in this order:

1. If this client has an in-app browser panel (Claude Code browser pane, Cowork browser panel), call `StataMCP:openVarsPage(launch=false)` and open the returned `url` **in that panel**
2. Without a panel (plain chat), call `StataMCP:openVarsPage(launch=true)`; if `status` is `url_only`, state the `url` in one line
3. Never run `window manage forward variables` for this — that raises Stata's own Variables pane, which has no selection or tags

To use the variables picked in the page, call `getSelectedVariables` (rules are in that tool's description and the `/stata-setup` summary).
