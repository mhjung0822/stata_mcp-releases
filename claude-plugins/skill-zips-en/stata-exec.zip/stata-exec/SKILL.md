---
name: stata-exec
description: |
  Dedicated to the /stata-exec slash command. Triggered only when the user types the /stata-exec slash command.
  Immediately executes /stata-exec $ARGUMENTS directly via StataMCP:executeStata,
  performing no interpretation, no modification, and no model inference.
  Do not trigger on natural-language Stata requests — respond only to an explicit /stata-exec call.
---

# stata-exec

When `/stata-exec $ARGUMENTS` is called:

1. Pass `$ARGUMENTS` verbatim to `StataMCP:executeStata`
2. Return the output as-is, wrapped in a code block
3. On error, return the error message as-is, wrapped in a code block

Do not modify, clean up, or evaluate `$ARGUMENTS`. Do not add any commentary before or after the code block.
In the response, `rc` = 0 means success; anything else is a Stata error code. For slow commands (~30s+), use `/stata-async`.
