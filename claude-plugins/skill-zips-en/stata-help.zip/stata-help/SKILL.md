---
name: stata-help
description: |
  Dedicated to the /stata-help slash command. Triggered only when the user types the /stata-help slash command.
  Immediately looks up help for /stata-help $ARGUMENTS via StataMCP:getHelp(command, selector),
  performing no interpretation, no modification, and no model inference.
  Do not trigger on natural-language Stata help requests — respond only to an explicit /stata-help call.
---

# stata-help

When `/stata-help $ARGUMENTS` is called:

1. Call `StataMCP:getHelp` with the **first token = command** and the **second token
   (if any) = selector**. However, if the second token is not selector-shaped ([a-z_.]+),
   treat the whole input as a multi-word keyword search (pass it whole as command, no selector)
2. Present the returned help **formatted as markdown** (the human-readable surface):
   - titles/model names → headings, option tables → markdown tables (option | abbrev | description),
     cmdlines and examples → ```stata code blocks, drill-down hints → inline code on the last line
   - **Technical tokens stay verbatim**: option names, syntax, commands, arguments,
     e()/r() names, [StataNow] markers — do not change a single character
   - **Descriptive prose stays in the original English, verbatim in meaning** — no summarizing,
     no omissions, no supplementing from your own knowledge
   - Only structural rearrangement is allowed — if you suspect any content alteration,
     show that part verbatim in a code block instead
3. On error, return the error message as-is, wrapped in a code block

## getHelp navigation rules (cascading — start cheap, descend only the branches you need)

- `selector=""` (omitted) → overview: title/description/requirements/model & syntax list +
  the keys you can narrow down with next
- **Universal selectors** (can be tried on any command):
  `options` (option table) / `optiondetails` (all option details) / `syntax` (full syntax —
  including free-form bodies like egen's function list or format's %fmt table) / `examples` /
  `stored` (e()/r()) / `usage` (prerequisites & constraints) / `remarks` / `desc` /
  `post` (postestimation command list) / `sections` (the full list of valid selectors for that command) / `full`
- **Dotted drill-down**: `<model>` (e.g. xtreg's `fe`) → `<model>.<group>` (`fe.se`) →
  `<model>.<option>` (`fe.vce` — the full detail text of a single option) /
  `post.<subcmd>` (`post.predict`) / `post.<subcmd>.<option>`
- **A nonexistent selector is not an error** — it returns the list of valid selectors
  for that command. For an unfamiliar command explore `""` → (if needed) `sections` → the target slice
- A `[StataNow]` marker on an option row = recently added feature (newer than your training
  data — when it conflicts with your own memory, trust the help)
- SSC/community commands are outside the structured corpus — selectors are ignored and
  the full raw help text is returned

## $ARGUMENTS examples

- `/stata-help xtreg` → overview (model list + drill-down keys)
- `/stata-help xtreg fe` → FE model cmdline + option table
- `/stata-help xtreg fe.vce` → full detail of the vce option
- `/stata-help regress post.predict` → predict statistic table
- `/stata-help egen syntax` → egen's ~40 function list
- `/stata-help random effects` → local keyword search (list of related commands)

Do not modify, clean up, or evaluate `$ARGUMENTS`. Do not add any commentary before or after the code blocks.
If the `getHelp` tool is not in the session's tool list (older server), say "The MCP server predates getHelp — server update required" and stop.
