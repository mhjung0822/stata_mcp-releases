---
name: stata-panel-merge
description: Use when combining Stata .dta files split by wave (round) into a single long panel. Triggered by requests like "merge the waves", "build a panel dataset", "convert to long", "make it xtset-able", "combine the wave files".
---

# Stata waves → long panel merge

## Procedure

1. **Identify the panel ID and wave** — what the person ID is, and whether the wave is split across files or held in a variable
2. **Work out the variable-naming convention** — is the wave marker a prefix or a suffix, how many digits (padding),
   are questionnaire items and derived variables separate series, which variables are time-invariant
3. **rename** — strip the wave markers to unify names
4. **append** — stack as a union and `xtset <id> wave`

Never hard-code variable or file names. Discover them fresh in step 2 every time.

**Keep every variable (union).** Do not ask in advance which variables will be used. It is better
to merge everything and pull out what's needed at analysis time. Items that exist only in some
waves become missing in the other waves' rows — that is normal.

---

## Hard rules

- **Do everything through StataMCP.** Never read .dta files with pandas, pyreadstat, or the like.
  That loses value labels / variable labels, mismatches type promotion, and destroys extended
  missing values (.a–.z).

- **Run with `StataMCP:executeStata` (synchronous). Do not use `executeStataAsync`.**
  Even if the files look big or the variables many. A merge requires checking each step's output
  (variable lists, leftover-prefix asserts, observation counts) before deciding the next step,
  so fire-and-forget execution that hides the results is the wrong tool.

- **When unsure of a Stata command's or option's syntax, check with `StataMCP:getHelp`.**
  Do not guess from memory. Commands with subtle syntax like `rename group` in particular must be
  read in the help first. On a syntax/option error (rc≠0), call getHelp immediately as well.

- **Do not use `reshape long`.** With prefixed variables the stubs number in the hundreds to
  thousands, making reshape impractically slow. Handle it with rename + append.

- **Strip prefixes with `rename group`'s numeric-group syntax.** It never bakes wave numbers
  into the code, so wave 10+ is safe. (`help rename group`)

  ```stata
  rename <derived-prefix>(##)* d_*[2]     // w03edu → d_edu
  rename <item-prefix>(##)* *[2]          // y03c001 → c001
  ```

  `(##)` = exactly 2 digits, `(#)` = 1 digit. Use the padding width confirmed in step 2.
  `*[2]` references the second token — a bare `*` would point at the numeric group and fail.
  Give derived variables their own prefix to avoid collisions with item stems, and rename
  **derived → items, in that order**.

- **Immediately after renaming, verify leftover prefixes with an assert. Never skip this.**

  ```stata
  capture ds <item-prefix>* <derived-prefix>*
  assert "`r(varlist)'" == ""
  ```

  rename passes **silently with zero matches** when the pattern doesn't fit (misjudged padding
  width is the classic case). If prefixed variables get appended, you get plausible-looking
  garbage with several times the variables. This assert is the only device that catches that
  silent failure.

- **Keep the rows exactly as distributed.** Do not filter the sample on your own initiative.
  Many panel surveys (Korean national panels in particular) keep a row for every original sample
  member in each wave file, leaving non-respondents as empty rows → a uniform `tab wave` across
  waves after append is normal. Tell the user that the real sample must be read from the response
  flag. Excluding non-respondents is the user's call at analysis time.

- **Run `xtset` before `save`.** The xtset setting is recorded as a dataset characteristic, so
  saving after xtset means a plain `use` later still has the panel set. xtset after saving leaves
  nothing in the file.

- **Never overwrite the original .dta.** Save under a new file name.

- **Before executing, present the planned approach and a draft do-file, and get approval.**

---

## Verification (never skip)

Right after append:

```stata
isid <id> wave                                        // panel-key uniqueness
by <id>: assert <time-invariant-var> == <time-invariant-var>[1]   // constant within person?
capture ds <item-prefix>* <derived-prefix>*
assert "`r(varlist)'" == ""                           // zero leftover prefixes
tab wave <response-flag>, m                           // response/non-response by wave

xtset <id> wave                                       // fix the panel structure
xtdescribe                                            // check the structure summary
compress
save "<new filename>", replace                        // ← save AFTER xtset
```

Reopen the saved file and confirm the setting actually persisted:

```stata
use "<new filename>", clear
xtset                                                 // no arguments → prints the stored setting
```

Even if `xtset` reports "strongly balanced", that may just reflect the retained non-respondent
rows. Report the actual respondent counts (`tab wave if <response-flag>==1`) alongside.

---

## Deliverables

- `<original-stub>_long.dta`
- `build_panel.do` (for reproducibility)
- Summary report: observations / variable count / actual respondents per wave / renaming rules applied
