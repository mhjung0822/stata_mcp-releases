---
name: stata-data-context
description: |
  Triggered when the user types /stata-data-context, or when the context needs refreshing after
  a change to the data's structure or contents (use/merge/drop/generate/replace/reshape etc.).
  Resynchronizes the current dataset context (pwd, obs, vars).
---

# stata-data-context

When called, run immediately in this order (for resynchronizing after data changes):

1. Run `StataMCP:getStataPwd`
2. Run `StataMCP:getObsCount`
3. Run `StataMCP:getVariables`

Return each result as-is, wrapped in a code block. Add no inference, interpretation, or commentary.

Environment (getStataEnv) and the working instructions are loaded by `/stata-setup` — excluded here.
For a deep profile (codebook, detailed summary), use `/stata-data-fullcontext`.
