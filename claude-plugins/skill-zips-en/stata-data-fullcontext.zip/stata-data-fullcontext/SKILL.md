---
name: stata-data-fullcontext
description: |
  Dedicated to the /stata-data-fullcontext slash command. Triggered only when the user types the /stata-data-fullcontext slash command.
  Immediately executes a fixed sequence to capture the full context of the current Stata dataset,
  then returns a detailed summary of the whole dataset.
  Do not trigger on natural-language Stata data requests — respond only to an explicit /stata-data-fullcontext call.
---

# stata-data-fullcontext

When `/stata-data-fullcontext` is called, run immediately in this order:

1. Run `StataMCP:getObsCount`
2. Run `StataMCP:getVariables`
3. Run `StataMCP:executeStata` — cmd: `codebook`

## Detailed summary after execution

Based on the three results above, print a full summary including:

- **Dataset overview**: number of observations, number of variables
- **Variable list**: as a markdown table (variable name, type, variable label, scale, value labels). Judge the scale as categorical / continuous / string by combining the presence of value labels, the number of distinct values, and the type. If a categorical variable's value labels exceed one line, continue them on the next row in the value-label column only, leaving the other cells blank. With more than 5 value labels, show `... and N more`. In the value-label column show only value=label mappings — do not show the label-set name (e.g. foreign, yesno).
- **Points of note**: variables with high missing rates, constant variables, and other things to watch in analysis. If an item is inferred beyond what the tool results contain, tag it `[inferred]`.
