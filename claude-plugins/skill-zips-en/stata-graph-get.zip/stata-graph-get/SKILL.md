---
name: stata-graph-get
description: |
  Dedicated to the /stata-graph-get slash command. Triggered only when the user types the /stata-graph-get slash command.
  Immediately queries the current graph's spec via StataMCP:getGraphSpec,
  performing no interpretation, no modification, and no model inference.
  Do not trigger on natural-language Stata graph requests — respond only to an explicit /stata-graph-get call.
---

# stata-graph-get

When `/stata-graph-get` is called:

1. Call `StataMCP:getGraphSpec` with an empty string (`name=""`) to fetch the current graph's spec
2. Return the resulting JSON as-is, wrapped in a code block
3. On error, return the error message as-is, wrapped in a code block

Takes no arguments; do not modify, clean up, or evaluate the result. Do not add any commentary before or after the code block.
